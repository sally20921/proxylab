#include "cache.h"


static int readcnt;
static int total_cache;
static long lru;

static struct cache_block *head;
struct CacheList *cache;

sem_t r,w;

void cache_init()
{
    total_cache = lru = readcnt = 0;
    head = 0;
    
    cache = (struct CacheList *)Malloc(sizeof(struct CacheList));
    cache->head = NULL;
    cache->size = 0;
    Sem_init(&r, 0, 1);
    Sem_init(&w, 0, 1);
}


int remove_block(struct cache_block * blo)
{
    Free(blo->block);
    Free(blo->request);
    Free(blo);
    return 1;
}

struct cache_block * alloc_block(int size)
{
    struct cache_block *blo;
    blo = (struct cache_block *)Malloc(sizeof (struct cache_block));
    blo->LRU = ++lru;

    blo->block = (char *)Malloc(size);
    blo->block_size = size;
    return blo;
}

int reader_check(char *request, char *buf)
{
    int len = 0;
    
    P(&r);
    ++readcnt;
    if (readcnt == 1)
    {
        P(&w);
    }
    V(&r);

    struct cache_block *temp = head;
    for (; temp; temp = temp->next)
        if (!strcasecmp(temp->request, request))
        {
            temp->LRU = ++lru;
            memcpy(buf, temp->block, temp->block_size);
            len = temp->block_size;
            break;
        }

    P(&r);
    --readcnt;
    if (!readcnt) {
        V(&w);
    }
    V(&r);

    return len;
}

void writer_check(char *request, char *block_data, int block_size)
{
    struct cache_block *temp;
    P(&w);
    while (total_cache + block_size >= MAX_CACHE_SIZE)
    {
        struct cache_block *vict = 0;

        for (temp = head; temp; temp = temp->next)
        {
            if (temp->LRU < vict->LRU)
                vict = temp;
        }

        total_cache -= vict->block_size;

        if (vict == head) {
            head = vict->next;
            if (head)
                head-> prev = NULL;
        }
        else {
            vict->prev->next = vict->next;
            if (vict->next)
                vict->next->prev = vict->prev;
        }

        (void) remove_block(vict);
    }

    total_cache += block_size;

    temp = alloc_block(block_size);

    memcpy(temp->block, block_data, block_size);

    if ((temp->request = (char *)malloc(strlen(request) + 1)) == NULL)
    {
        fprintf(stderr, "%s\n", "memory malloc error");
    }
    strcpy(temp->request, request);

    if (head) {
        head->prev = temp;
        temp->next = head;
        temp->prev = NULL;
        head = temp;
    }
    else {
        head = temp;
        head->next = head->prev = NULL;
    }
    
    V(&w);
}
