#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "csapp.h"

#include "cache.h"
/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

#define METHOD_LEN 25
#define VERSION_LEN 15
#define PORT_LEN 25
//#define DEFAULT_PORT 80

/* You won't lose style points for including this long line in your code */
static char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; " \
"Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";
static char *connection_hdr = "Connection: close\r\n";
static char *proxy_connection_hdr = "Proxy-Connection: close\r\n";
static char *server_version = "HTTP/1.0";
static char *default_port = "80";
//static char *type_header = "Content-type";
//static char *type_text = "text";




struct Request
{
    char request[MAXLINE];
    char method[METHOD_LEN];
    char host_addr[MAXLINE];
    char port[PORT_LEN];
    char path[MAXLINE];
    char version[VERSION_LEN];
};


int parse_request(rio_t *rio,char *request, struct Request *req);
int from_client_to_server(rio_t *rio, char *buf, struct Request *req, int serverfd, int clientfd);
int from_server_to_client(rio_t *rio_to_server, int serverfd, int clientfd, char *cachebuf);
void *handle_client(void *vargp);
//int get_response_header_type(char *buf);


int main(int argc, char **argv)
{
    Signal(SIGPIPE, SIG_IGN);
    
    if (argc != 2)
    {
        fprintf(stderr, "usage: %s <port> <cache disable>\n", argv[0]);
        exit(1);
    }
    
    cache_init();
    
    {
        int listenfd = Open_listenfd(argv[1]);
        
        struct sockaddr_storage clientaddr;
        
        while (1)
        {
            socklen_t clientlen = sizeof(clientaddr);
            
            int clientfd =
            Accept(listenfd, (SA *)&clientaddr, &clientlen);
            
            pthread_t tid;
            Pthread_create(&tid, NULL,
                           handle_client, (void *)(long)clientfd);
        }
    }
}


void *handle_client(void *vargp)
{
    Pthread_detach(Pthread_self());
    
    int clientfd = (int) (long) vargp;
    rio_t rio_to_client;
    Rio_readinitb(&rio_to_client, clientfd);
    
    struct Request req;
    memset((char *)&req, 0,sizeof (struct Request));
    
    
    char request[MAXLINE];
    parse_request(&rio_to_client, request, &req);
    //parse request from the client
    
    
    ssize_t n;
    char cached_obj[MAX_OBJECT_SIZE];
    n = reader_check(req.request, cached_obj);
    Rio_writen(clientfd, cached_obj, n);
    
    int serverfd;
    serverfd =Open_clientfd(req.host_addr, req.port);
    
    from_client_to_server(&rio_to_client, request,
                          &req, serverfd, clientfd);
    
    static char cachebuf[MAX_OBJECT_SIZE];
    int sizebuf;
    sizebuf = from_server_to_client(NULL,serverfd, clientfd, cachebuf);
    
    if (sizebuf < MAX_OBJECT_SIZE) {
    	writer_check(req.request, cachebuf, sizebuf);
    }
    
    
    Close(serverfd);
    Close(clientfd);
    
    return NULL;
}


int parse_request(rio_t *rio,
                  char *request, struct Request *req)
{
//GET http://csapp.cs.cmu.edu:80/index.html HTTP/1.1

    static char uri[MAXLINE]; //http://csapp.cs.cmu.edu:80/index.html
    static char version[VERSION_LEN]; //HTTP/1.1
    static char method[METHOD_LEN]; //GET
    
    Rio_readlineb(rio, request, MAXLINE);
    
    sscanf(request, "%s %s %s", method, uri, version);

    //uri : http://csapp.cs.cmu.edu:80/index.html
    //hostname: csapp.cs.cmu.edu
    //hostname_port: 80
    //path: /index.html

    strcpy(req->request, request);
    strcpy(req->method, method);
    strcpy(req->version, version);

    char hostname[MAXLINE];
    char hostname_port[MAXLINE];
    char path[MAXLINE];
    char port[PORT_LEN];
    
    path[0] = '/';
    
    char *temp = uri;
    temp = strstr(temp, "://");
    temp = temp+strlen("://");
    sscanf(temp, "%[^/]%s",
           hostname_port, path);
    sscanf(hostname_port, "%[^:]:%s",
           hostname, port);
    
    strcpy(req->host_addr, hostname);
    strcpy(req->path, path);
    
    if (strlen(port) == 0)
    {
        strcpy(req->port, default_port); 
    }
    else
    {
        strcpy(req->port, port);
    }
    
    return 0;
}


int from_client_to_server(rio_t *rio, char *buf,
                          struct Request *req, int serverfd, int clientfd)
{
    static char requestheader_pool[MAXLINE];
    int m = 0;
    static char *requestheaders[MAXLINE];
    
    
    if (!strcasecmp(req->method, "GET")) {

        int n;
        char *current_ptr = requestheader_pool;
        
        while (1)
        {
            n = rio_readlineb(rio, current_ptr, MAXLINE);
            
            if (n < 0) {
            return -1;
	    }
            
            requestheaders[m++] = current_ptr;
            current_ptr[n] = '\0';
            
            char *header_str = current_ptr;
            
            current_ptr[n] = '\0';
            current_ptr += n + 1;
            
            if (!strcmp(header_str, "\r\n")) {
                break;
            }
        }
        
        static char req_final[MAXLINE];
        
        n = snprintf(req_final, MAXLINE, "%s %s %s\r\n",
                     req->method,
                     *req->path ? req->path : "/",
                     server_version);  
        
        Rio_writen(serverfd, req_final, n);
        
        int has_agent_hdr = 0; //User-Agent: 
        int has_conn_hdr = 0; //Connection: 
        int has_host_hdr = 0; //Host:
 
        static char host_hdr[MAXLINE];        
        snprintf(host_hdr, MAXLINE,
                 "Host: %s\r\n",
                 req->host_addr);
        
        int t;
        for(t = 0; t < m; ++t)
        {
            char *header_str = requestheaders[t];
            
            if (!memcmp(header_str,
                        "User-Agent:",
                        strlen("User-Agent:"))) {
		has_agent_hdr = 1;
                Rio_writen(serverfd,user_agent_hdr,strlen(user_agent_hdr));
                
            }
            
            else if (!memcmp(header_str,
                        "Connection:",
                        strlen("Connection:"))) {
		has_conn_hdr = 1;
                Rio_writen(serverfd,connection_hdr,strlen(connection_hdr));
            }
            
            else if (!memcmp(header_str,
                        "Proxy-Connection:",
                        strlen("Proxy-Connection:"))) {
		 has_conn_hdr = 1;
                Rio_writen(serverfd,proxy_connection_hdr, strlen(proxy_connection_hdr));

            }
            
            else if (!memcmp(header_str,
                        "Host:",
                        strlen("Host:"))) {
               
                has_host_hdr = 1;
                Rio_writen(serverfd,host_hdr,strlen(host_hdr));
            }
            
            else {
             Rio_writen(serverfd,header_str,strlen(header_str));
            }
        }
        
        if (!has_agent_hdr) {
           
            Rio_writen(serverfd, user_agent_hdr,strlen(user_agent_hdr));
        }
        
        if (!has_conn_hdr){
            
            Rio_writen(serverfd,connection_hdr,strlen(connection_hdr));
           
        }
        
        if (!has_host_hdr) {
            
            Rio_writen(serverfd,host_hdr,strlen(host_hdr));
        }
        
        return 1;
    }
    
   return 0;
}


int from_server_to_client(rio_t *rio_to_server,
                          int serverfd, int clientfd, char *cachebuf)
{
    
    char buf[MAXLINE]={};
    cachebuf[0] = '\0';
    int sizebuf = 0;
    ssize_t n;
    
    //int tt = 0;
    while((n=rio_readn(serverfd, buf, MAXLINE)) != 0)
    {
        /*if (n < 0)
        {
            ++tt;
            fprintf(stderr, "error 1. %s %d\n", strerror(errno), tt);
            return -1;
        }*/

        buf[n] = '\0';
        if (sizebuf < MAX_OBJECT_SIZE)
        {
            sizebuf += n;
            if (sizebuf < MAX_OBJECT_SIZE) {
		strcat(cachebuf, buf);
	    }
            else {
            	sizebuf = MAX_OBJECT_SIZE;
	    }
        }
        
        //n = rio_writen(clientfd,buf,n);
        /*if (n < 0)
        {
            fprintf(stderr, "error 2. %s\n", strerror(errno));
            return -2;
        }*/
	Rio_writen(clientfd, buf, n);
        
    }
    
    return sizebuf;
    
    /*int content_text_type = 0;
    
    rio_t srio;
    Rio_readinitb(&srio, serverfd);
    
    while ((n = rio_readlineb(&srio, buf, MAXLINE)) != 0)
    {
        if (n < 0)
        return -1;
        
        if (sizebuf < MAX_OBJECT_SIZE)
        {
            sizebuf += n;
            if (sizebuf < MAX_OBJECT_SIZE)
            strcat(cachebuf, buf);
            else
            sizebuf = MAX_OBJECT_SIZE;
        }
        
        n = rio_writen(clientfd, buf, n);
        if (n < 0)
        return -2;
        
        if(strcmp(buf, "\r\n") == 0)
        {
            printf("termination received\n");
            break;
        }
        
        content_text_type |= get_response_header_type(buf);
    }
    
    
    if(content_text_type == 1)
    {
        while((n = rio_readlineb(&srio, buf, MAXLINE)) != 0)
        {
            if (n < 0)
            return -1;
            
            if (sizebuf < MAX_OBJECT_SIZE)
            {
                sizebuf += n;
                if (sizebuf < MAX_OBJECT_SIZE) {
                strcat(cachebuf, buf); 
		}
                else {
                sizebuf = MAX_OBJECT_SIZE;
		}
            }
            
            n = rio_writen(clientfd, buf, n);
            if (n < 0)
            return -2;
        }
    }
    
    else
    {
        while((n = rio_readnb(&srio, buf, MAXLINE)) != 0)
        {
            if (n < 0)
            return -1;
            
            if (sizebuf < MAX_OBJECT_SIZE)
            {
                sizebuf += n;
                if (sizebuf < MAX_OBJECT_SIZE)
                strcat(cachebuf, buf);
                else
                sizebuf = MAX_OBJECT_SIZE;
            }
            
            n = rio_writen(clientfd, buf, n);
            if (n < 0)
            return -2;
        }
    }
    
    
    return sizebuf;*/
}



/*int get_response_header_type(char *buf)
{
    
    static char item[MAXLINE], type[MAXLINE];
    
    sscanf(buf, "%[^:]:%[^/]/%*s", item, type);
    
    if(!strcasecmp(item, type_header))
    {
        return 1 + (!!strcasecmp(type, type_text));
    }
    return 0;
}*/


